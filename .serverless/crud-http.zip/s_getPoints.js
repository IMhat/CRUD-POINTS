
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mateomansilla',
  applicationName: 'crud-http',
  appUid: '2KQrZPFsc7XFVPGrRk',
  orgUid: '05091cc4-8514-4598-ab68-d984bdc81c15',
  deploymentUid: '394efcd5-1ea7-4473-9107-7ebbf4cf5f73',
  serviceName: 'crud-http',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'crud-http-dev-getPoints', timeout: 6 };

try {
  const userHandler = require('./src/getPoints.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getPoints, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}